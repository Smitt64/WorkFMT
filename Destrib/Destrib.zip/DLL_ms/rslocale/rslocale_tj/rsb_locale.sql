/**
 * ����� ������� �������������� ����� � ��������� ����������. 
 * ���������� ��� ����������� �����.
 */
CREATE OR REPLACE PACKAGE RSB_LOCALE AS
/******************************************************************************
   NAME:       RSB_LOCALE
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        22.01.2008                   1. Created this package.
   2.0        07.03.2013  Azartsov V.V.    
******************************************************************************/

TYPE TOEMTOWIDE IS VARRAY(512) OF INTEGER;
TYPE TWIDETOOEM IS VARRAY(512) OF INTEGER;

/**
 * ������� ��������� ������� �� ����
 */
FUNCTION OEMCODE_TO_CHAR(p_code IN NUMBER) RETURN CHAR;

/**
 * ������� ��������� ���� �������
 */
FUNCTION CHAR_TO_OEMCODE(p_char IN CHAR  ) RETURN NUMBER;

/**
 * ������� ��������� OEM �������
 */
function CHAR_TO_OEM(NC IN NCHAR) return NCHAR;

/**
 * ������� ��������� OEM ������
 */
function STRING_TO_OEM(NS IN NVARCHAR2) return NVARCHAR2;

/**
 * ������� ��������� UNICODE �������
 */
function CHAR_TO_UNICODE(C IN NCHAR) return NCHAR;

/**
 * ������� ��������� UNICODE ������
 */
function STRING_TO_UNICODE(S IN NVARCHAR2) return NVARCHAR2;

/**
 * ������� �������������� ������ � RAW
 */
function OEM_TO_RAW(S IN NVARCHAR2) return RAW;

/**
 * ������� �������������� RAW � ������
 */
function RAW_TO_OEM(R IN RAW) return NVARCHAR2;

/**
 * ������� ��������� ��������� ���� ������
 */
function GET_NLS_CHARSET return VARCHAR2;

/**
 * ������� �������������� ���������� ������������� ����������������� ���� � ����������� �������������� ����
 */
function FROM_HEX(C IN VARCHAR2) return INTEGER;

/**
 * ���������� ������ (����������)
 */
g_OemToWide TOEMTOWIDE;
g_WideToOem TWIDETOOEM;
G_NLS_CHARSET VARCHAR2(40);

/**
 * ��������� ������������� ����� �������������� �������� OEM � UNICODE
 */
procedure InitOemToWideMap;

/**
 * ��������� ������������� ����� �������������� �������� UNICODE � OEM
 */
procedure InitWideToOemMap;

/**
 * ��������� ������ (����������)
 */
NUMLATIN CONSTANT INTEGER := 32;
NUMCYR   CONSTANT INTEGER := 256;
NUMPUNCT CONSTANT INTEGER := 48;
NUMGRAPH CONSTANT INTEGER := 160;
BEGSPEC  CONSTANT INTEGER := NUMLATIN + NUMCYR + NUMPUNCT + NUMGRAPH;

DEF_CHAR CONSTANT CHAR    := '?';

END RSB_LOCALE;
/

/**
 * ����� ������� �������������� ����� � ��������� ����������. 
 * ���������� ��� ������������ �����.
 */
CREATE OR REPLACE PACKAGE BODY RSB_LOCALE
IS

FUNCTION OEMCODE_TO_CHAR(p_code IN NUMBER) RETURN CHAR AS
  nls VARCHAR2(32000);
  v_code NUMBER;
BEGIN

  nls := GET_NLS_CHARSET();

  IF nls = 'AL32UTF8' THEN
    IF    p_code >= 128 AND p_code <= 175 THEN v_code := p_code + 53264;
    ELSIF p_code >= 224 AND p_code <= 239 THEN v_code := p_code + 53408;
    ELSIF p_code  = 240                   THEN v_code := p_code + 53137;
    ELSIF p_code  = 241                   THEN v_code := p_code + 53408;
    ELSE  v_code := p_code;
    END IF;
  ELSE  v_code := p_code;
  END IF;

  RETURN CHR(v_code);
END;

FUNCTION CHAR_TO_OEMCODE(p_char IN CHAR  ) RETURN NUMBER AS
  v_code NUMBER;
BEGIN

  v_code := ASCII( p_char );

  IF    v_code >= 53392 AND v_code <= 53439 THEN v_code := v_code - 53264;
  ELSIF v_code >= 53632 AND v_code <= 53647 THEN v_code := v_code - 53408;
  ELSIF v_code =  53377                     THEN v_code := v_code - 53137;
  ELSIF v_code =  53649                     THEN v_code := v_code - 53408;
  END IF;

  RETURN v_code;
END;

function FROM_HEX(C IN VARCHAR2) return INTEGER as
begin
   return UTL_RAW.CAST_TO_BINARY_INTEGER(HEXTORAW(C));
end;


procedure InitOemToWideMap as
begin
   -- �஢�ઠ �� ������ ⠡���� ᨬ�����
   IF g_OemToWide IS NULL THEN
       g_OemToWide := TOEMtoWIDE(
/*00*/    FROM_HEX('0000'), FROM_HEX('0001'), FROM_HEX('0002'), FROM_HEX('0003'), FROM_HEX('0004'), FROM_HEX('0005'), FROM_HEX('0006'), FROM_HEX('0007'),
/*08*/    FROM_HEX('0008'), FROM_HEX('0009'), FROM_HEX('000A'), FROM_HEX('000B'), FROM_HEX('000C'), FROM_HEX('000D'), FROM_HEX('000E'), FROM_HEX('000F'),
/*10*/    FROM_HEX('0010'), FROM_HEX('0011'), FROM_HEX('0012'), FROM_HEX('0013'), FROM_HEX('0014'), FROM_HEX('0015'), FROM_HEX('0016'), FROM_HEX('0017'),
/*18*/    FROM_HEX('0018'), FROM_HEX('0019'), FROM_HEX('001A'), FROM_HEX('001B'), FROM_HEX('001C'), FROM_HEX('001D'), FROM_HEX('001E'), FROM_HEX('001F'),
/*20*/    FROM_HEX('0020'), FROM_HEX('0021'), FROM_HEX('0022'), FROM_HEX('0023'), FROM_HEX('0024'), FROM_HEX('0025'), FROM_HEX('0026'), FROM_HEX('0027'),
/*28*/    FROM_HEX('0028'), FROM_HEX('0029'), FROM_HEX('002A'), FROM_HEX('002B'), FROM_HEX('002C'), FROM_HEX('002D'), FROM_HEX('002E'), FROM_HEX('002F'),
/*30*/    FROM_HEX('0030'), FROM_HEX('0031'), FROM_HEX('0032'), FROM_HEX('0033'), FROM_HEX('0034'), FROM_HEX('0035'), FROM_HEX('0036'), FROM_HEX('0037'),
/*38*/    FROM_HEX('0038'), FROM_HEX('0039'), FROM_HEX('003A'), FROM_HEX('003B'), FROM_HEX('003C'), FROM_HEX('003D'), FROM_HEX('003E'), FROM_HEX('003F'),
/*40*/    FROM_HEX('0040'), FROM_HEX('0041'), FROM_HEX('0042'), FROM_HEX('0043'), FROM_HEX('0044'), FROM_HEX('0045'), FROM_HEX('0046'), FROM_HEX('0047'),
/*48*/    FROM_HEX('0048'), FROM_HEX('0049'), FROM_HEX('004A'), FROM_HEX('004B'), FROM_HEX('004C'), FROM_HEX('004D'), FROM_HEX('004E'), FROM_HEX('004F'),
/*50*/    FROM_HEX('0050'), FROM_HEX('0051'), FROM_HEX('0052'), FROM_HEX('0053'), FROM_HEX('0054'), FROM_HEX('0055'), FROM_HEX('0056'), FROM_HEX('0057'),
/*58*/    FROM_HEX('0058'), FROM_HEX('0059'), FROM_HEX('005A'), FROM_HEX('005B'), FROM_HEX('005C'), FROM_HEX('005D'), FROM_HEX('005E'), FROM_HEX('005F'),
/*60*/    FROM_HEX('0060'), FROM_HEX('0061'), FROM_HEX('0062'), FROM_HEX('0063'), FROM_HEX('0064'), FROM_HEX('0065'), FROM_HEX('0066'), FROM_HEX('0067'),
/*68*/    FROM_HEX('0068'), FROM_HEX('0069'), FROM_HEX('006A'), FROM_HEX('006B'), FROM_HEX('006C'), FROM_HEX('006D'), FROM_HEX('006E'), FROM_HEX('006F'),
/*70*/    FROM_HEX('0070'), FROM_HEX('0071'), FROM_HEX('0072'), FROM_HEX('0073'), FROM_HEX('0074'), FROM_HEX('0075'), FROM_HEX('0076'), FROM_HEX('0077'),
/*78*/    FROM_HEX('0078'), FROM_HEX('0079'), FROM_HEX('007A'), FROM_HEX('007B'), FROM_HEX('007C'), FROM_HEX('007D'), FROM_HEX('007E'), FROM_HEX('007F'),

/*80*/    FROM_HEX('0410'), FROM_HEX('0411'), FROM_HEX('0412'), FROM_HEX('0413'), FROM_HEX('0414'), FROM_HEX('0415'), FROM_HEX('0416'), FROM_HEX('0417'),
/*88*/    FROM_HEX('0418'), FROM_HEX('0419'), FROM_HEX('041A'), FROM_HEX('041B'), FROM_HEX('041C'), FROM_HEX('041D'), FROM_HEX('041E'), FROM_HEX('041F'),
/*90*/    FROM_HEX('0420'), FROM_HEX('0421'), FROM_HEX('0422'), FROM_HEX('0423'), FROM_HEX('0424'), FROM_HEX('0425'), FROM_HEX('0426'), FROM_HEX('0427'),
/*98*/    FROM_HEX('0428'), FROM_HEX('0429'), FROM_HEX('042A'), FROM_HEX('042B'), FROM_HEX('042C'), FROM_HEX('042D'), FROM_HEX('042E'), FROM_HEX('042F'),
/*A0*/    FROM_HEX('0430'), FROM_HEX('0431'), FROM_HEX('0432'), FROM_HEX('0433'), FROM_HEX('0434'), FROM_HEX('0435'), FROM_HEX('0436'), FROM_HEX('0437'),
/*A8*/    FROM_HEX('0438'), FROM_HEX('0439'), FROM_HEX('043A'), FROM_HEX('043B'), FROM_HEX('043C'), FROM_HEX('043D'), FROM_HEX('043E'), FROM_HEX('043F'),
/*B0*/    FROM_HEX('2591'), FROM_HEX('2592'), FROM_HEX('2593'), FROM_HEX('2502'), FROM_HEX('2524'), FROM_HEX('2561'), FROM_HEX('2562'), FROM_HEX('2556'),
/*B8*/    FROM_HEX('2555'), FROM_HEX('2563'), FROM_HEX('2551'), FROM_HEX('2557'), FROM_HEX('255D'), FROM_HEX('255C'), FROM_HEX('255B'), FROM_HEX('2510'),
/*C0*/    FROM_HEX('2514'), FROM_HEX('2534'), FROM_HEX('252C'), FROM_HEX('251C'), FROM_HEX('2500'), FROM_HEX('253C'), FROM_HEX('255E'), FROM_HEX('255F'),
/*C8*/    FROM_HEX('255A'), FROM_HEX('2554'), FROM_HEX('2569'), FROM_HEX('2566'), FROM_HEX('2560'), FROM_HEX('2550'), FROM_HEX('256C'), FROM_HEX('2567'),
/*D0*/    FROM_HEX('2568'), FROM_HEX('2564'), FROM_HEX('2565'), FROM_HEX('2559'), FROM_HEX('2558'), FROM_HEX('2552'), FROM_HEX('2553'), FROM_HEX('256B'),
/*D8*/    FROM_HEX('256A'), FROM_HEX('2518'), FROM_HEX('250C'), FROM_HEX('2588'), FROM_HEX('2584'), FROM_HEX('258C'), FROM_HEX('2590'), FROM_HEX('2580'),
/*E0*/    FROM_HEX('0440'), FROM_HEX('0441'), FROM_HEX('0442'), FROM_HEX('0443'), FROM_HEX('0444'), FROM_HEX('0445'), FROM_HEX('0446'), FROM_HEX('0447'),
/*E8*/    FROM_HEX('0448'), FROM_HEX('0449'), FROM_HEX('044A'), FROM_HEX('044B'), FROM_HEX('044C'), FROM_HEX('044D'), FROM_HEX('044E'), FROM_HEX('044F'),
/*F0*/    FROM_HEX('0401'), FROM_HEX('0451'), FROM_HEX('049A'), FROM_HEX('049B'), FROM_HEX('04B2'), FROM_HEX('04B3'), FROM_HEX('04B6'), FROM_HEX('04B7'),
/*F8*/    FROM_HEX('04E2'), FROM_HEX('04E3'), FROM_HEX('04EE'), FROM_HEX('221A'), FROM_HEX('2116'), FROM_HEX('04Ef'), FROM_HEX('25A0'), FROM_HEX('00A0')
);

    END IF;
end;

procedure InitWideToOemMap as
begin
   -- �஢�ઠ �� ������ ⠡���� ᨬ�����
   IF g_WideToOem IS NULL THEN
       g_WideToOem := TWIDEtoOEM(
-- Latin
/* A0 */    FROM_HEX('FF'), ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('FD'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* A8 */    ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* B0 */    FROM_HEX('F8'), ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('FA'),
/* B8 */    ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),

-- Cyrillic
/* 400 (1024)*/   ASCII('?'),  FROM_HEX('F0'), ASCII('?'),  ASCII('?'),  FROM_HEX('F2'), ASCII('?'),  FROM_HEX('F6'), FROM_HEX('F4'),
/* 408 (1032)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('F6'), ASCII('?'),
/* 410 (1040)*/   FROM_HEX('80'), FROM_HEX('81'), FROM_HEX('82'), FROM_HEX('83'), FROM_HEX('84'), FROM_HEX('85'), FROM_HEX('86'), FROM_HEX('87'),
/* 418 (1048)*/   FROM_HEX('88'), FROM_HEX('89'), FROM_HEX('8A'), FROM_HEX('8B'), FROM_HEX('8C'), FROM_HEX('8D'), FROM_HEX('8E'), FROM_HEX('8F'),
/* 420 (1056)*/   FROM_HEX('90'), FROM_HEX('91'), FROM_HEX('92'), FROM_HEX('93'), FROM_HEX('94'), FROM_HEX('95'), FROM_HEX('96'), FROM_HEX('97'),
/* 428 (1064)*/   FROM_HEX('98'), FROM_HEX('99'), FROM_HEX('9A'), FROM_HEX('9B'), FROM_HEX('9C'), FROM_HEX('9D'), FROM_HEX('9E'), FROM_HEX('9F'),
/* 430 (1072)*/   FROM_HEX('A0'), FROM_HEX('A1'), FROM_HEX('A2'), FROM_HEX('A3'), FROM_HEX('A4'), FROM_HEX('A5'), FROM_HEX('A6'), FROM_HEX('A7'),
/* 438 (1080)*/   FROM_HEX('A8'), FROM_HEX('A9'), FROM_HEX('AA'), FROM_HEX('AB'), FROM_HEX('AC'), FROM_HEX('AD'), FROM_HEX('AE'), FROM_HEX('AF'),
/* 440 (1088)*/   FROM_HEX('E0'), FROM_HEX('E1'), FROM_HEX('E2'), FROM_HEX('E3'), FROM_HEX('E4'), FROM_HEX('E5'), FROM_HEX('E6'), FROM_HEX('E7'),
/* 448 (1096)*/   FROM_HEX('E8'), FROM_HEX('E9'), FROM_HEX('EA'), FROM_HEX('EB'), FROM_HEX('EC'), FROM_HEX('ED'), FROM_HEX('EE'), FROM_HEX('EF'),
/* 450 (1104)*/   ASCII('?'),  FROM_HEX('F1'), ASCII('?'),  ASCII('?'),  FROM_HEX('F3'), ASCII('?'),  ASCII('?'),  FROM_HEX('F5'),
/* 458 (1112)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('F7'),  ASCII('?'),
/* 460 (1120)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 468 (1128)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 470 (1136)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 478 (1144)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 480 (1152)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 488 (1160)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 490 (1168)*/   ASCII('?'),  ASCII('?'),  FROM_HEX('1C'),  FROM_HEX('1D'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 498 (1176)*/   ASCII('?'),  ASCII('?'),  FROM_HEX('F2'),  FROM_HEX('F3'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),

/* 4A0 (1184)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4A8 (1192)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4B0 (1200)*/   ASCII('?'),  ASCII('?'),  FROM_HEX('F4'),  FROM_HEX('F5'),  ASCII('?'),  ASCII('?'),  FROM_HEX('F6'),  FROM_HEX('F7'),
/* 4B8 (1208)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4C0 (1216)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4C8 (1224)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4D0 (1232)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4D8 (1240)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4E0 (1248)*/   ASCII('?'),  ASCII('?'),  FROM_HEX('F8'),  FROM_HEX('F9'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4E8 (1256)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('FA'),  FROM_HEX('FD'),
/* 4F0 (1264)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 4F8 (1272)*/   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),

/* 2010 */  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2018 */  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2020 */  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2028 */  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2030 */  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2038 */  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),

/* 2500 */   FROM_HEX('C4'), ASCII('?'),  FROM_HEX('B3'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2508 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('DA'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2510 */   FROM_HEX('BF'), ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('C0'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2518 */   FROM_HEX('D9'), ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('C3'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2520 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('B4'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2528 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('C2'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2530 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('C1'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2538 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('C5'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2540 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2548 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2550 */   FROM_HEX('CD'), FROM_HEX('BA'), FROM_HEX('D5'), FROM_HEX('D6'), FROM_HEX('C9'), FROM_HEX('B8'), FROM_HEX('B7'), FROM_HEX('BB'),
/* 2558 */   FROM_HEX('D4'), FROM_HEX('D3'), FROM_HEX('C8'), FROM_HEX('BE'), FROM_HEX('BD'), FROM_HEX('BC'), FROM_HEX('C6'), FROM_HEX('C7'),
/* 2560 */   FROM_HEX('CC'), FROM_HEX('B5'), FROM_HEX('B6'), FROM_HEX('B9'), FROM_HEX('D1'), FROM_HEX('D2'), FROM_HEX('CB'), FROM_HEX('CF'),
/* 2568 */   FROM_HEX('D0'), FROM_HEX('CA'), FROM_HEX('D8'), FROM_HEX('D7'), FROM_HEX('CE'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2570 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2578 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2580 */   FROM_HEX('DF'), ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('DC'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2588 */   FROM_HEX('DB'), ASCII('?'),  ASCII('?'),  ASCII('?'),  FROM_HEX('DD'), ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2590 */   FROM_HEX('DE'), FROM_HEX('B0'), FROM_HEX('B1'), FROM_HEX('B2'), ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),
/* 2598 */   ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),  ASCII('?'),

--Special
/* 20AC */  ASCII('?'),
/* 2116 */  FROM_HEX('FC'),
/* 2122 */  ASCII('?'),
/* 2219 */  FROM_HEX('F9'),
/* 221A */  FROM_HEX('FB'),
/* 25A0 */  FROM_HEX('FE'),
/* 25BA */  FROM_HEX('10'),
/* 25C4 */  FROM_HEX('11')

);
    END IF;
end;

function CHAR_TO_OEM(NC IN NCHAR) return NCHAR as
    C    NCHAR;
    nls  VARCHAR2(160);
    code INTEGER;
begin
    nls := GET_NLS_CHARSET();



    IF nls = 'AL32UTF8' THEN
        InitWideToOemMap();

        code := ASCII(NC);
        
--DBMS_OUTPUT.PUT_LINE(code);        

--------------------------------------------------------------------
        IF code < FROM_HEX('80') THEN
        
            C := nchr(code);
        ELSIF code >= FROM_HEX('A0') AND code <= FROM_HEX('BF') THEN
        
            C := nchr(g_WideToOem (code - FROM_HEX('A0') + 1));
        ELSIF code >= FROM_HEX('400') AND code <= FROM_HEX('4FF') THEN
        
               C := nchr(g_WideToOem(code - FROM_HEX('400') + NUMLATIN + 1));
        ELSIF code >= FROM_HEX('2010') AND code <= FROM_HEX('203F') THEN
        
               C := nchr(g_WideToOem (code - FROM_HEX('2010') + NUMLATIN + NUMCYR + 1));
        ELSIF code >= FROM_HEX('2500') AND code <= FROM_HEX('259F') THEN
        
               C := nchr(g_WideToOem(code - FROM_HEX('2500') + NUMLATIN + NUMCYR + NUMPUNCT + 1));
        ELSIF code = FROM_HEX('20AC') THEN
        
               C := nchr(g_WideToOem(BEGSPEC + 1));
        ELSIF code = FROM_HEX('2116') THEN
        
               C := nchr(g_WideToOem(BEGSPEC + 2));
        ELSIF code = FROM_HEX('2122') THEN
        
               C := nchr(g_WideToOem(BEGSPEC + 3));
        ELSIF code = FROM_HEX('2219') THEN
        
               C := nchr(g_WideToOem(BEGSPEC + 4));
        ELSIF code = FROM_HEX('221A') THEN
        
               C := nchr(g_WideToOem(BEGSPEC + 5));
        ELSIF code = FROM_HEX('25A0') THEN
        
               C := nchr(g_WideToOem(BEGSPEC + 6));
        ELSE
        
            C := '?';
        END IF;
--------------------------------------------------------------------
    ELSE
        C := NC;
    END IF;
    
    --DBMS_OUTPUT.PUT_LINE(C);

    return C;
end;

function STRING_TO_OEM(NS IN NVARCHAR2) return NVARCHAR2 as
    C   NCHAR;
    S   NVARCHAR2(32000);
    len INTEGER;
    nls VARCHAR2(32000);
begin
    nls := GET_NLS_CHARSET();

    IF nls = 'AL32UTF8' THEN
        len := LENGTH(NS);

        FOR i IN 1..len LOOP
        C := CHAR_TO_OEM(unistr(REPLACE(SUBSTR(NS, i, 1), '\', '\\')));
           S := S || C;
           
        END LOOP;
    ELSE
        S := NS;
    END IF;

    return S;
end;

function CHAR_TO_UNICODE(C IN NCHAR) return NCHAR as
    nc  NCHAR;
    code INTEGER;
    nls  VARCHAR2(32000);
begin
    nls := GET_NLS_CHARSET();

    IF nls = 'AL32UTF8' THEN
        InitOemToWideMap();
        code := g_OemToWide(ascii(C) + 1);

        nc := nchr(code);
    ELSE
        nc := C;
    END IF;

    return nc;
end;

function STRING_TO_UNICODE(S IN NVARCHAR2) return NVARCHAR2 as
    ns  NVARCHAR2(32000);
    len INTEGER;
    nls VARCHAR2(32000);
begin
    nls := GET_NLS_CHARSET();
        IF S IS NULL THEN
           return NULL;
        END IF;

    IF nls = 'AL32UTF8' THEN
        len := LENGTH(S);

        FOR i IN 1..len LOOP
        
           ns := ns || CHAR_TO_UNICODE(UNISTR( REPLACE(SUBSTR(S, i, 1), '\', '\\')));
        END LOOP;
    ELSE
        ns := s;
    END IF;

    return ns;
end;

function OEM_TO_RAW(S IN NVARCHAR2) return RAW AS
    hex_str     NVARCHAR2(32000);
    hex_str_res NVARCHAR2(32000);
    c           NCHAR;
    len         INTEGER;
    hex_len     INTEGER;
    nls         NVARCHAR2(32000);
begin
    nls := GET_NLS_CHARSET();

    IF nls = 'AL32UTF8' THEN

        len := LENGTH(S);

        FOR i IN 1..len LOOP
               c := SUBSTR(S, i,1);

            hex_str := RAWTOHEX(UTL_RAW.CAST_TO_RAW(c));

            hex_len := LENGTH(hex_str);

            IF     hex_len > 2 THEN
                hex_str := SUBSTR(hex_str, hex_len - 1, 2);
            END IF;

            hex_str_res := hex_str_res||hex_str;

        END LOOP;

        return HEXTORAW(hex_str_res);

    END IF;

    return utl_raw.cast_to_raw(S);
end;

function RAW_TO_OEM(R IN RAW) return NVARCHAR2 AS
    str         VARCHAR2(32000);
    str_res     NVARCHAR2(32000);
    nls         NVARCHAR2(32000);
    c           CHAR;
    len         INTEGER;
    code        INTEGER;
begin
   nls := GET_NLS_CHARSET();
      IF R IS NOT NULL THEN
         IF nls = 'AL32UTF8' THEN

            len := UTL_RAW.LENGTH(R);
            FOR i IN 1..len LOOP
                  code := UTL_RAW.CAST_TO_BINARY_INTEGER(unistr(REPLACE(UTL_RAW.SUBSTR(R, i, 1), '\', '\\')));

               str_res := str_res||nchr(code);
            END LOOP;
        ELSE
        str_res := utl_raw.cast_to_varchar2(R);
        END IF;
      END IF;

      return str_res;
end;

FUNCTION GET_NLS_CHARSET RETURN VARCHAR2 AS
BEGIN
   IF G_NLS_CHARSET IS NULL THEN
      SELECT VALUE INTO G_NLS_CHARSET FROM NLS_DATABASE_PARAMETERS WHERE PARAMETER = 'NLS_CHARACTERSET';
      --DBMS_OUTPUT.PUT_LINE('GET_NLS_CHARSET INIT!!!!');
   END IF;

   RETURN G_NLS_CHARSET;
END;

END RSB_LOCALE;
/
