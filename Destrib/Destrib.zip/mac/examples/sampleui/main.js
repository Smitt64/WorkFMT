ImportExt("fmt.Ui");
var uifile = $macroDirPath + "/sampleui.ui";
var widget = LoadUiXml(uifile);
var tableNameEdit, comboBox;

if (typeof widget !== undefined)
{
	var table = pTable.toFmtTable(); 
	var pushButton = widget.findChild("pushButton");
	tableNameEdit = widget.findChild("tableNameEdit");
    comboBox = widget.findChild("comboBox");
    
	tableNameEdit.text = table.Name;
	tableNameEdit.readOnly = true;
    
    // AddToComboBox(comboBox, "1", "2", "3");
    AddToComboBox(comboBox, FmtLib.allFmtTypes());

	pushButton.clicked.connect(pushButtonClicked);
	var result = widget.exec();
	if (result === 1)
		Print("Widget Accepted");
	else
		Print("Widget Rejected");
}
else
	Print("Error loading ui: ", uifile);

function pushButtonClicked() {
	widget.windowTitle = tableNameEdit.text;
}