ImportExt("fmt.Ui");
var table = pTable.toFmtTable();
var uifile = $macroDirPath + "/rstorecord.ui";
var widget = LoadUiXml(uifile);
var plainTextEdit, structEdit, rsEdit, tbButton;

function main() {
    if (typeof widget !== undefined)
    {
        var genButton = widget.findChild("genButton");
        plainTextEdit = widget.findChild("plainTextEdit");
        structEdit = widget.findChild("structEdit");
        rsEdit = widget.findChild("rsEdit");
        tbButton = widget.findChild("tbButton");
        genButton.clicked.connect(genButtonClicked);
        
        structEdit.text = table.DbtName;
        rsEdit.text = "rs";
        widget.exec();
    }
}

function genButtonClicked() {
    var text = "";
    for (var i = 0; i < table.fieldsCount(); i++) 
    {
        var fld = table.field(i);
        text += structEdit.text + ".";
        
        if (tbButton.checked)
            text += "rec.";
        
        text += fld.UndecorateName + " = ";
        text += rsEdit.text + ".value(\"" + fld.Name + "\");";
        text += "\n";
    }        
	plainTextEdit.setPlainText(text);
}

main();